"""Parametric resonance: frozen prediction against the exact Floquet exponent.

Reproduces Table S3 of the Supplemental Material. The frequency is modulated at
twice the mean frequency,

    Omega(t) = Omega_0 [1 + m cos(2 Omega_0 t)],

and the effective generator of Sec. S4 is integrated with the SIGNED coefficient
b(t) = (dOmega/dt) / (2 Omega). The modulation is periodic with T_p = pi/Omega_0,
so the growth is characterised exactly by the largest Floquet exponent

    mu_F = ln(rho[Phi(T_p, 0)]) / T_p,

with rho the spectral radius of the monodromy matrix. This is independent of any
choice of norm and of the integration time.
"""

import numpy as np
from scipy.integrate import solve_ivp

OM0 = 1.0
TP = np.pi / OM0


def Omega(t, m):
    return OM0 * (1.0 + m * np.cos(2.0 * OM0 * t))


def b_signed(t, m):
    dOm = -2.0 * OM0**2 * m * np.sin(2.0 * OM0 * t)
    return dOm / (2.0 * Omega(t, m))


def M_eff(t, m, signed=True):
    b = b_signed(t, m)
    if not signed:
        b = abs(b)
    return np.array([[b, Omega(t, m)], [-Omega(t, m), -b]])


def propagator(m, T, signed=True):
    def rhs(t, y):
        return (M_eff(t, m, signed) @ y.reshape(2, 2)).ravel()
    sol = solve_ivp(rhs, [0, T], np.eye(2).ravel(),
                    rtol=1e-12, atol=1e-14, dense_output=False)
    return sol.y[:, -1].reshape(2, 2)


def floquet_exponent(m, signed=True):
    Phi = propagator(m, TP, signed)
    rho = max(abs(np.linalg.eigvals(Phi)))
    return np.log(rho) / TP, np.linalg.det(Phi)


def max_eta(m):
    t = np.linspace(0, TP, 20000)
    return np.max(np.abs(-2 * OM0**2 * m * np.sin(2 * OM0 * t)) / Omega(t, m)**2)


if __name__ == "__main__":
    print("TABLE S3.  Frozen-flow prediction against the exact Floquet exponent")
    print("  Rates in units of Omega_0; the frozen prediction is identically zero")
    print("  because the frozen matrix is elliptic at every instant (max eta < 2).")
    print(f"  {'m':>6}{'max eta':>10}{'frozen':>9}{'mu_F':>12}"
          f"{'T^-1 ln||Phi||':>16}{'det Phi':>12}")
    for m in [0.02, 0.05, 0.10, 0.20, 0.40]:
        mu, det = floquet_exponent(m)
        T = 400.0
        finite = np.log(np.linalg.norm(propagator(m, T), 2)) / T
        print(f"  {m:6.2f}{max_eta(m):10.3f}{0:9d}{mu:12.6f}"
              f"{finite:16.5f}{det:12.6f}")

    print("\n  mu_F follows the parametric-resonance rate m*Omega_0/2:")
    for m in [0.02, 0.05, 0.10]:
        mu, _ = floquet_exponent(m)
        print(f"    m = {m:4.2f}:  mu_F = {mu:.6f},  m/2 = {m/2:.6f}")

    print("\n  Replacing b(t) by its modulus suppresses the growth, which is why")
    print("  the signed coefficient is kept:")
    for m in [0.02]:
        signed, _ = floquet_exponent(m, signed=True)
        unsigned, _ = floquet_exponent(m, signed=False)
        print(f"    m = {m:4.2f}:  signed mu_F = {signed:.6f}, "
              f"unsigned = {unsigned:.6f}, ratio = {signed/max(unsigned,1e-12):.0f}")
