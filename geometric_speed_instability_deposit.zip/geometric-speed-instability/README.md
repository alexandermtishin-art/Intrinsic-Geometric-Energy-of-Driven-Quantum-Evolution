# Code deposit — Quantum-Geometric Speed Does Not Determine Dynamical Instability in Driven Bosonic Systems

A. M. Tishin, Lomonosov Moscow State University and Moscow Institute of Physics and Technology.

This deposit contains the numerical work supporting the manuscript. Every claim
in the paper that carries a number is reproduced by one of the scripts below.
The two theorems are proved analytically in the manuscript; the corresponding
scripts are implementation checks, not evidence.

## Contents

| File | What it establishes |
|---|---|
| `theorem1_identity.py` | The identity 8 v_FS² = Tr G² + Tr M², evaluated from the Gaussian variance formula at the bare-mode vacuum for random symmetric generators at N = 1…6, together with an independent Fock-basis evaluation of Var(H) for the detuned amplifier. |
| `theorem2_sharp_bound.py` | Each step of the sharp bound λ_max ≤ √2 v_FS: the anticommutation SJ + JS = 0, the resulting ± pairing of the spectrum of S, the inequality ‖S‖_F² ≥ 2 μ_max²(S), the Bendixson step, the saturating family, and the vanishing symmetric part of passive generators. |
| `reciprocal_families.py` | Tables 1 and 2 of the manuscript: the two reciprocal families of a detuned parametric amplifier, the closed form ⟨n(t)⟩ = 2 (v_FS/λ)² sinh²(λt), the quadrature structure along Family A, and the elliptic case excluded from both families. |
| `photon_number_and_open_window.py` | The closed form for ⟨n(t)⟩ against direct covariance propagation, the quadrature variances and covariance, and the open-system window of Table 3 obtained from the full Lyapunov equation including vacuum-noise refill. |
| `fig1_panels.py` | The four panels of Fig. 1. |
| `results.txt` | Reference output of the four computational scripts, for comparison. |

## Key numerical results

**Theorem 1.** The identity holds to machine zero at every mode number tested,
the two sides reducing to the same sequence of floating-point operations. The
Fock-basis evaluation returns Var(H) = ε²/2 to twelve digits at four detunings,
confirming the detuning independence outside the symplectic formalism used to
derive it.

**Theorem 2.** SJ + JS = 0 holds to machine zero for N = 1…6. The spectrum of S
pairs as ±μ to 1.7 × 10⁻¹⁴, and ‖S‖_F² − 2 μ_max² is non-negative with residual
no worse than −7 × 10⁻¹⁵. Over 1.2 × 10⁵ random generators at N = 1…6 neither
the Bendixson step nor the bound is violated, the largest sampled ratio being
0.99999999. Random Gaussian generators do not approach saturation for N > 1,
whereas the structured saturating family of the proof — one resonant squeezer
with spectator modes — returns λ_max /(√2 v_FS) = 1.000000000000 at every N from
1 to 5. Passive additions, constructed by projection onto [J, G_p] = 0, leave
M_p + M_pᵀ = 0 exactly and v_FS unchanged to all displayed digits while the
largest exponent varies over the full range.

**Reciprocal families.** Along Family A the asymptotic growth rate is 2.000000
in units of λ₀ at every point while the short-time fidelity decay spans two
orders of magnitude. Along Family B the short-time decay is identical to four
digits while the occupation reached at εt = 8 spans four orders of magnitude.
At λ₀t = 0.8 the quadrature anisotropy across four members of Family A runs
24.5, 67.0, 313.9 and 1123.6 and the squeezing axis rotates from 135.0° to
103.3°, so the members are observably distinct at identical exponent.

**Open-system window.** With κ/2π = 20 MHz and ε/2π = 50 MHz the exponents are
−κ/2 ± λ and net instability requires λ > κ/2. Family B is traversable for
δ/ε ≤ 0.9798, over which λ falls from 50 to 10 MHz. Occupations and saturation
times are obtained from dΣ/dt = M_open Σ + Σ M_openᵀ + κ Σ_vac; omitting the
vacuum-noise refill underestimates the occupation by an order of magnitude near
the edge of the family.

## Requirements

Python 3 with `numpy`, `scipy` and `matplotlib`. No other dependencies. Each
script is standalone and runs in well under a minute:

```
python theorem1_identity.py
python theorem2_sharp_bound.py
python reciprocal_families.py
python photon_number_and_open_window.py
python fig1_panels.py
```

Random draws use fixed seeds, so the sampled figures quoted above reproduce
exactly. The analytic checks are seed-independent.

## Conventions

Quadratures are ordered z = (x₁, p₁, …, x_N, p_N) with the canonical symplectic
form J satisfying J² = −1. A quadratic generator is H = ½ zᵀGz with G real
symmetric, and the flow matrix is M = JG. The bare-mode vacuum has covariance
Σ = ½·1 in the convention Σ_ij = ½⟨{z_i − ⟨z_i⟩, z_j − ⟨z_j⟩}⟩. Frequency units
are used throughout (ℏ = 1); the factor converting a speed to an energy
multiplies both sides of every identity equally.

## License

The code is released under the MIT License.
