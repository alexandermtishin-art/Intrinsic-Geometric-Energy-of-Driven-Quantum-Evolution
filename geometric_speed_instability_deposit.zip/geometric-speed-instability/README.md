# Code deposit — Quantum-Geometric Bound on Dynamical Instability in Bosonic Systems

A. M. Tishin, Lomonosov Moscow State University and Moscow Institute of Physics and Technology.

This deposit contains the numerical work behind the Letter and its Supplemental
Material. Every number in the Letter, and every number in the Supplemental
Material except those of Sec. S7, is reproduced by one of the scripts below; the
transmon computation of Sec. S7 is the separate, earlier code held in the same
repository and is not duplicated here. The two theorems are proved analytically,
so the scripts attached to them are implementation checks, not evidence.

## Contents

| File | What it establishes |
|---|---|
| `theorem1_identity.py` | The identity 8 v_FS² = Tr G² + Tr M², evaluated from the Gaussian variance formula at the bare-mode vacuum for random symmetric generators at N = 1…6, with an independent Fock-basis evaluation of Var(H) for the detuned amplifier. |
| `theorem2_sharp_bound.py` | Each step of the sharp bound λ_max ≤ √2 v_FS: the anticommutation SJ + JS = 0, the resulting ± pairing of the spectrum of S, the inequality ‖S‖_F² ≥ 2 μ_max²(S), the Bendixson step, the saturating squeezer-plus-spectators family, and the vanishing symmetric part of passive generators. |
| `reciprocal_families.py` | Table I of the Letter and its Table S1 extension: both reciprocal families of the detuned parametric amplifier, the closed form ⟨n(t)⟩ = 2 (v_FS/λ)² sinh²(λt), the quadrature structure along Family A, and the elliptic case excluded from both families. |
| `photon_number_and_open_window.py` | The closed form for ⟨n(t)⟩ against direct covariance propagation, the quadrature variances and covariance, and the open-system window of Table II of the Letter, obtained from the full Lyapunov equation including vacuum-noise refill. |
| `fig1_prl.py` | The four panels of Fig. 1 of the Letter. |
| `chirped_mode.py` | Table S2 and the symplectic normal-form check of Sec. S4: the squeezing rate against the instantaneous frozen-flow exponent, and the conjugation of the frozen flow to a canonical dilatation of rate λ_loc. |
| `parametric_resonance.py` | Table S3 of Sec. S5: the exact Floquet exponent of the modulated mode against the identically vanishing frozen prediction, with the monodromy determinant as a symplecticity check. |
| `mixed_state_thermal.py` | The closed forms of Sec. S6 against a 900-level Fock-basis evaluation of the quantum Fisher information and the energy uncertainty. |
| `fig_thermal.py` | Fig. S3 of the Supplemental Material: the mixed-state speed and the energy uncertainty for a driven thermal mode. |
| `results.txt` | Reference output of the seven computational scripts, for comparison without running them. |

## Key numerical results

**Theorem 1.** The identity holds to machine zero at every mode number tested,
the two sides reducing to the same sequence of floating-point operations. The
Fock-basis evaluation returns Var(H) = ε²/2 to twelve digits at four detunings,
confirming the detuning independence outside the symplectic formalism used to
derive it.

**Theorem 2.** SJ + JS = 0 holds to machine zero for N = 1…6. The spectrum of S
pairs as ±μ to 1.7 × 10⁻¹⁴, and ‖S‖_F² − 2 μ_max² is non-negative with residual
no worse than −7 × 10⁻¹⁵. Over 1.2 × 10⁵ random generators at N = 1…6 neither
the Bendixson step nor the bound is violated, the largest sampled ratio being
0.99999999. Random Gaussian generators do not approach saturation for N > 1,
whereas the structured saturating family of the proof — one resonant squeezer
with spectator modes — returns λ_max /(√2 v_FS) = 1.000000000000 at every N from
1 to 5. Passive additions, constructed by projection onto [J, G_p] = 0, leave
M_p + M_pᵀ = 0 exactly and v_FS unchanged to all displayed digits while the
largest exponent varies over the full range.

**Reciprocal families.** Along Family A the asymptotic growth rate is 2.000000
in units of λ₀ at δ/λ₀ = 0, 1, 2, 3, 5, 10 while the short-time fidelity decay
runs 2.000×10⁻⁴, 3.998×10⁻⁴, 9.986×10⁻⁴, 1.994×10⁻³, 5.160×10⁻³, 1.961×10⁻².
Along Family B the short-time decay is identical to four digits at δ/ε = 0, 0.5,
0.9, 0.99 while the occupation reached at εt = 8 runs 2.22×10⁶, 3.47×10⁵,
1.40×10³, 9.62×10¹. At λ₀t = 0.8 the quadrature anisotropy across the four
Table I members of Family A runs 24.5, 67.0, 313.9 and 1123.6 and the squeezing
axis rotates from 135.0° to 103.3°, so the members are observably distinct at
identical exponent.

**Open-system window.** With κ/2π = 20 MHz and ε/2π = 50 MHz, that is
ε/ε_th = 5 with ε_th = κ/2, the exponents are −κ/2 ± λ and net instability
requires λ > κ/2. Family B is traversable for δ/ε ≤ 0.9798, over which λ falls
from 50 to 10 MHz. Occupations and saturation times follow from
dΣ/dt = M_open Σ + Σ M_openᵀ + κ Σ_vac; omitting the vacuum-noise refill
underestimates the occupation by an order of magnitude near the edge of the
family. The same script also reports when the logarithmic growth rate settles
to within 5 % of its asymptotic value against the time to reach 100 photons:
7.1 ns versus 11.5 ns on resonance and 13.7 versus 18.2 ns at δ/ε = 0.8,
leaving 2.2 and 1.1 e-folds of clean exponential growth, with the window
narrowing to 0.4 e-folds at δ/ε = 0.9 and closing at 0.95.

**Supplemental calculations.** The chirped-mode comparison returns overestimates
of 66.7, 41.4, 34.2, 15.5 and 2.1 per cent at η = 2.5, √8, 3, 4 and 10, and the
frozen flow above threshold conjugates to λ_loc diag(1, −1) with symplecticity
and diagonalization residuals of 1.1 × 10⁻¹⁶ and 8.9 × 10⁻¹⁶. At parametric
resonance the frozen prediction vanishes identically while the Floquet exponent
follows mΩ₀/2, returning 0.009999, 0.024977, 0.049817, 0.098550 and 0.188798 at
m = 0.02, 0.05, 0.10, 0.20 and 0.40, with det Φ = 1 to 10⁻¹²; replacing the
signed coefficient by its modulus suppresses the growth by a factor of forty at
m = 0.02. The thermal closed forms agree with the 900-level Fock-basis
evaluation to machine precision for n̄ ≤ 10, the residual rising to 10⁻⁹ at
n̄ = 30 where the truncation begins to bite.

## Requirements

Python 3 with `numpy`, `scipy` and `matplotlib`. No other dependencies. Each
script is standalone and runs in well under a minute:

```
python theorem1_identity.py
python theorem2_sharp_bound.py
python reciprocal_families.py
python photon_number_and_open_window.py
python chirped_mode.py
python parametric_resonance.py
python mixed_state_thermal.py
python fig1_prl.py
python fig_thermal.py
```

Random draws use fixed seeds, so the sampled figures quoted above reproduce
exactly. The analytic checks are seed-independent.

## Conventions

Quadratures are ordered z = (x₁, p₁, …, x_N, p_N) with the canonical symplectic
form J satisfying J² = −1. A quadratic generator is H = ½ zᵀGz with G real
symmetric, and the flow matrix is M = JG. The bare-mode vacuum has covariance
Σ = ½·1 in the convention Σ_ij = ½⟨{z_i − ⟨z_i⟩, z_j − ⟨z_j⟩}⟩. Frequency units
are used throughout (ℏ = 1); the factor converting a speed to an energy
multiplies both sides of every identity equally.

## License

The code is released under the MIT License.
