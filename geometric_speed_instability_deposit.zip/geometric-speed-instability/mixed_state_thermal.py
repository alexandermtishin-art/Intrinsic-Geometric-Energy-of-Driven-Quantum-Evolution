"""Mixed states: closed forms against a Fock-basis evaluation (Sec. S6).

For a thermal state of mean occupation n_bar evolving under the squeezing
generator H_perp = (i hbar / 2)(B a^dag^2 - B* a^2), with kappa_s = |B|,

    v      = kappa_s sqrt(1 - 1/(2W)),
    Delta H = hbar kappa_s sqrt(W/2),        W = 1 + 2 n_bar + 2 n_bar^2.

The quantum Fisher information of the time parameter is

    F_Q = (2/hbar^2) sum_ij (p_i - p_j)^2/(p_i + p_j) |<i|H_perp|j>|^2,

and v = sqrt(F_Q)/2. H_perp connects n to n +- 2 only, so the double sum
collapses to a single sum; the Fock space is truncated at 900 levels, as in the
Supplemental Material.
"""

import numpy as np

NCUT = 900
HBAR = 1.0
KAPPA_S = 1.0          # units of kappa_s throughout


def thermal_populations(nbar, ncut=NCUT):
    if nbar == 0:
        p = np.zeros(ncut)
        p[0] = 1.0
        return p
    x = nbar / (1.0 + nbar)
    n = np.arange(ncut)
    p = (1.0 - x) * x**n
    return p / p.sum()


def qfi_speed(nbar, ncut=NCUT):
    """v = sqrt(F_Q)/2 from the Fock-basis sum."""
    p = thermal_populations(nbar, ncut)
    n = np.arange(ncut - 2)
    # |<n+2|H_perp|n>|^2 = (hbar kappa_s / 2)^2 (n+1)(n+2)
    mel2 = (HBAR * KAPPA_S / 2.0) ** 2 * (n + 1) * (n + 2)
    num = (p[n + 2] - p[n]) ** 2
    den = p[n + 2] + p[n]
    good = den > 0
    # the pair (i,j) and (j,i) both contribute
    F_Q = (2.0 / HBAR**2) * 2.0 * np.sum(num[good] / den[good] * mel2[good])
    return 0.5 * np.sqrt(F_Q)


def energy_uncertainty(nbar, ncut=NCUT):
    p = thermal_populations(nbar, ncut)
    n = np.arange(ncut)
    second = (HBAR * KAPPA_S / 2.0) ** 2 * np.sum(
        p * ((n + 1) * (n + 2) + n * (n - 1)))
    return np.sqrt(second)          # <H_perp> = 0


def closed_forms(nbar):
    W = 1.0 + 2.0 * nbar + 2.0 * nbar**2
    return KAPPA_S * np.sqrt(1.0 - 1.0 / (2.0 * W)), HBAR * KAPPA_S * np.sqrt(W / 2.0)


if __name__ == "__main__":
    print("Closed forms of Eq. (S6) against a 900-level Fock-basis evaluation")
    print("  (rates in units of kappa_s, energies in units of hbar kappa_s)")
    print(f"  {'n_bar':>7}{'v (Fock)':>13}{'v (closed)':>13}{'dev':>11}"
          f"{'DH (Fock)':>13}{'DH (closed)':>13}{'dev':>11}")
    for nbar in [0.0, 0.1, 0.5, 1.0, 3.0, 10.0, 30.0]:
        v_num, dh_num = qfi_speed(nbar), energy_uncertainty(nbar)
        v_cf, dh_cf = closed_forms(nbar)
        print(f"  {nbar:7.1f}{v_num:13.9f}{v_cf:13.9f}{abs(v_num-v_cf):11.2e}"
              f"{dh_num:13.6f}{dh_cf:13.6f}{abs(dh_num-dh_cf):11.2e}")

    print("\n  The residual grows at n_bar = 30, where the 900-level truncation")
    print("  begins to bite; below n_bar = 10 both agree to machine precision.")
    v0, _ = closed_forms(0.0)
    vinf, _ = closed_forms(1e6)
    print(f"\n  v is bounded: {v0:.6f} at n_bar = 0 (= 1/sqrt2) rising to "
          f"{vinf:.6f} as n_bar -> infinity,")
    print("  a total variation of sqrt2, while Delta H grows without bound.")
