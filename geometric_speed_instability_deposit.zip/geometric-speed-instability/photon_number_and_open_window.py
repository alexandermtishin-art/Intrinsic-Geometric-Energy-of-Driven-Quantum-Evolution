import numpy as np
from scipy.linalg import expm
from scipy.integrate import solve_ivp

J = np.array([[0., 1.], [-1., 0.]])
def MG(d, e):
    G = np.diag([d + e, d - e]); return J @ G, G

# ---------------------------------------------------------------
# 1. closed form  n(t) = (eps^2/lam^2) sinh^2(lam t) = 2 (v_FS/lam)^2 sinh^2(lam t)
# ---------------------------------------------------------------
print("CLOSED FORM CHECK:  n(t) = 2 (v_FS/lambda)^2 sinh^2(lambda t)")
print(f"{'delta':>7}{'eps':>8}{'t':>6}{'numeric n':>16}{'closed form':>16}{'rel err':>11}")
for d, e, t in [(0,1,1),(2,np.sqrt(5),1),(0.9,1,1),(5,np.sqrt(26),3),(0.99,1,8),(0,1,6)]:
    M, G = MG(d, e)
    S = expm(M*t); Sig = S @ (0.5*np.eye(2)) @ S.T
    num = 0.5*np.trace(Sig) - 0.5
    lam = np.sqrt(e*e - d*d); v = e/np.sqrt(2)
    cf = 2*(v/lam)**2 * np.sinh(lam*t)**2
    print(f"{d:7.2f}{e:8.3f}{t:6.1f}{num:16.6e}{cf:16.6e}{abs(num-cf)/num:11.2e}")

# quadrature variances and covariance
print("\nQUADRATURE CHECK at delta=2, eps=sqrt(5), t=0.8")
d, e, t = 2.0, np.sqrt(5), 0.8
lam = np.sqrt(e*e-d*d)
M, G = MG(d, e); S = expm(M*t); Sig = S @ (0.5*np.eye(2)) @ S.T
vx = 0.5*(np.cosh(lam*t)**2 + (d-e)**2/lam**2*np.sinh(lam*t)**2)
vp = 0.5*(np.cosh(lam*t)**2 + (d+e)**2/lam**2*np.sinh(lam*t)**2)
cov = -(e/lam)*np.sinh(lam*t)*np.cosh(lam*t)
print(f"  Var x: numeric {Sig[0,0]:.8f}  formula {vx:.8f}")
print(f"  Var p: numeric {Sig[1,1]:.8f}  formula {vp:.8f}")
print(f"  Cov  : numeric {Sig[0,1]:.8f}  formula {cov:.8f}")

# squeezing axis orientation across Family A (lambda fixed)
print("\nSQUEEZING AXIS across FAMILY A (lambda = 1 fixed), at t = 0.8")
for dl in [0., 1., 2., 3.]:
    lam0 = 1.0; d = dl*lam0; e = np.sqrt(lam0**2 + d**2)
    M, G = MG(d, e); S = expm(M*0.8); Sig = S @ (0.5*np.eye(2)) @ S.T
    w, V = np.linalg.eigh(Sig)
    ang = np.degrees(np.arctan2(V[1, -1], V[0, -1]))
    n = 0.5*np.trace(Sig)-0.5
    print(f"  delta/lam0={dl:4.1f}: n={n:9.4f}  prefactor eps^2/lam^2={e*e/lam0**2:6.2f}"
          f"  squeeze axis={ang:7.2f} deg  Var_max/Var_min={w[-1]/w[0]:9.2f}")

# ---------------------------------------------------------------
# 2. open system with the CORRECT Lyapunov equation (vacuum noise refill)
#    dSigma/dt = M_k Sigma + Sigma M_k^T + kappa * Sigma_vac,  M_k = M - (kappa/2) 1
# ---------------------------------------------------------------
TWOPI = 2*np.pi
def rad(fMHz): return TWOPI*fMHz*1e-3
def MHz(r):    return r/TWOPI*1e3

kappa = rad(20.0); eps = 5*(kappa/2)

def n_open(d, e, tmax, npts=4000):
    M, _ = MG(d, e); Mk = M - (kappa/2)*np.eye(2)
    Sv = 0.5*np.eye(2)
    def rhs(t, y):
        S = y.reshape(2, 2)
        return (Mk@S + S@Mk.T + kappa*Sv).ravel()
    sol = solve_ivp(rhs, [0, tmax], Sv.ravel(), t_eval=np.linspace(0, tmax, npts),
                    rtol=1e-10, atol=1e-12)
    ns = 0.5*(sol.y[0] + sol.y[3]) - 0.5
    return sol.t, ns

def t_reach(d, e, target=100.0, tmax=400.0):
    t, ns = n_open(d, e, tmax, 20000)
    idx = np.where(ns >= target)[0]
    return np.inf if len(idx) == 0 else t[idx[0]]

print("\n" + "="*82)
print("OPEN-SYSTEM WINDOW, Lyapunov equation with vacuum-noise refill")
print(f"  kappa/2pi = {MHz(kappa):.1f} MHz,  eps/2pi = {MHz(eps):.2f} MHz (5x threshold)")
print(f"  v_FS/2pi = {MHz(eps/np.sqrt(2)):.2f} MHz identically")
print("="*82)
print(f"{'d/eps':>7}{'delta/2pi':>11}{'lam/2pi':>10}{'2(lam-k/2)':>12}{'<n> 20ns':>12}{'t_sat(100)':>12}")
for de in [0.0, 0.5, 0.8, 0.9, 0.95, 0.9798]:
    d = de*eps; lam = np.sqrt(max(eps**2-d**2, 0.0))
    t, ns = n_open(d, eps, 20.0)
    ts = t_reach(d, eps)
    ts_s = "inf" if not np.isfinite(ts) else f"{ts:.1f}"
    print(f"{de:7.3f}{MHz(d):11.2f}{MHz(lam):10.2f}{2*(lam-kappa/2):12.4f}{ns[-1]:12.3e}{ts_s:>12}")

print("\ncompare: deterministic-damping-only estimate at d/eps=0.9 was 4.8 photons at 20 ns")

# ---------------------------------------------------------------
# Measurement window: when does the logarithmic growth rate settle to
# its asymptotic value, and does that happen before Kerr saturation?
# ---------------------------------------------------------------
if __name__ == "__main__":
    from scipy.integrate import solve_ivp as _ivp
    print("\n" + "=" * 82)
    print("READABILITY OF THE ASYMPTOTIC EXPONENT (Table II of the Letter)")
    print("=" * 82)
    print(f"{'d/eps':>7}{'2(lam-k/2)':>13}{'t_settle(5%)':>14}{'t_sat(100)':>12}{'e-folds':>10}")
    for de in [0.0, 0.5, 0.8, 0.9, 0.95]:
        d = de * eps
        lam = np.sqrt(max(eps**2 - d**2, 0.0))
        asym = 2 * (lam - kappa / 2)
        M, _ = MG(d, eps)
        Mk = M - (kappa / 2) * np.eye(2)
        Sv = 0.5 * np.eye(2)
        sol = _ivp(lambda t, y: (Mk @ y.reshape(2, 2) + y.reshape(2, 2) @ Mk.T
                                 + kappa * Sv).ravel(),
                   [0, 400], Sv.ravel(), t_eval=np.linspace(1e-3, 400, 40000),
                   rtol=1e-11, atol=1e-13)
        nb = 0.5 * (sol.y[0] + sol.y[3]) - 0.5
        rate = np.gradient(np.log(nb), sol.t)
        ok = np.where(np.abs(rate - asym) / asym < 0.05)[0]
        t_set = sol.t[ok[0]] if len(ok) else np.inf
        hit = np.where(nb >= 100)[0]
        t_sat = sol.t[hit[0]] if len(hit) else np.inf
        ef = asym * (t_sat - t_set)
        print(f"{de:7.2f}{asym:13.4f}{t_set:14.1f}{t_sat:12.1f}{ef:10.2f}")
    print(f"\n  1/(lam + kappa/2) on resonance = {1/(eps + kappa/2):.2f} ns")
