import numpy as np
rng = np.random.default_rng(7)

def Jmat(N):
    J = np.zeros((2*N, 2*N))
    for k in range(N):
        J[2*k, 2*k+1] = 1.0
        J[2*k+1, 2*k] = -1.0
    return J

def var_gaussian(G, Sigma, J):
    # Var(H) for H = 1/2 z^T G z in a Gaussian state with covariance Sigma
    return 0.5*np.trace(G@Sigma@G@Sigma) + 0.125*np.trace(G@J@G@J)

print("N   max|8Var - (TrG^2+TrM^2)|   (bare vacuum Sigma = I/2)")
for N in range(1, 7):
    J = Jmat(N)
    Sig = 0.5*np.eye(2*N)
    worst = 0.0
    for _ in range(500):
        A = rng.normal(size=(2*N, 2*N))
        G = A + A.T
        M = J@G
        lhs = 8*var_gaussian(G, Sig, J)
        rhs = np.trace(G@G) + np.trace(M@M)
        worst = max(worst, abs(lhs-rhs))
    print(f"{N}   {worst:.3e}")

# Independent Fock-basis check for one mode: H = delta(x^2+p^2)/2 + (eps/2)(x^2-p^2)
Ncut = 400
a = np.diag(np.sqrt(np.arange(1, Ncut)), 1)
ad = a.T
x = (a+ad)/np.sqrt(2); p = (a-ad)/(1j*np.sqrt(2))
print("\nFock-basis check of Var(H)=eps^2/2 for the detuned amplifier:")
for delta, eps in [(0.0, 1.0), (0.7, 1.0), (0.99, 1.0), (2.0, 0.3)]:
    H = delta*(x@x + p@p)/2 + (eps/2)*(x@x - p@p)
    v0 = np.zeros(Ncut); v0[0] = 1.0
    m1 = (v0 @ H @ v0).real
    m2 = (v0 @ H @ H @ v0).real
    print(f"  delta={delta:4.2f} eps={eps:4.2f}: Var={m2-m1**2:.12f}  eps^2/2={eps**2/2:.12f}")
