import numpy as np
rng = np.random.default_rng(17)

def Jm(N):
    J = np.zeros((2*N, 2*N))
    for k in range(N):
        J[2*k, 2*k+1] = 1.0; J[2*k+1, 2*k] = -1.0
    return J

print("STEP 1.  S = (M+M^T)/2 = (JG - GJ)/2 anticommutes with J:  SJ + JS = 0")
worst = 0.0
for N in range(1, 7):
    J = Jm(N)
    for _ in range(400):
        A = rng.normal(size=(2*N, 2*N)); G = A + A.T; M = J @ G
        S = (M + M.T)/2
        worst = max(worst, np.max(np.abs(S@J + J@S)))
print(f"   max |SJ + JS| over N=1..6 : {worst:.3e}")

print("\nSTEP 2.  eigenvalues of S occur in opposite pairs  =>  ||S||_F^2 >= 2 mu_max^2")
worst_pair = 0.0; worst_ineq = 0.0
for N in range(1, 7):
    J = Jm(N)
    for _ in range(400):
        A = rng.normal(size=(2*N, 2*N)); G = A + A.T; M = J @ G
        S = (M + M.T)/2
        ev = np.sort(np.linalg.eigvalsh(S))
        worst_pair = max(worst_pair, np.max(np.abs(ev + ev[::-1])))   # symmetry of spectrum
        mu = ev[-1]
        worst_ineq = min(worst_ineq, np.sum(S*S) - 2*mu**2)           # must be >= 0
print(f"   max |mu_j + mu_(n+1-j)| : {worst_pair:.3e}   (exact pairing)")
print(f"   min (||S||_F^2 - 2 mu_max^2) : {worst_ineq:.3e}   (must be >= 0)")

print("\nSTEP 3.  Bendixson chain:  lam_max <= mu_max(S) <= ||S||_F/sqrt2 = sqrt2 v_FS")
viol_b = 0; viol_f = 0; worst_ratio = 0.0
for N in range(1, 7):
    J = Jm(N)
    for _ in range(20000):
        A = rng.normal(size=(2*N, 2*N)); G = A + A.T; M = J @ G
        S = (M + M.T)/2
        lam = np.max(np.real(np.linalg.eigvals(M)))
        mu = np.max(np.linalg.eigvalsh(S))
        v = np.linalg.norm(M + M.T)/4
        if lam > mu + 1e-9: viol_b += 1
        if lam > np.sqrt(2)*v + 1e-9: viol_f += 1
        if v > 0: worst_ratio = max(worst_ratio, lam/(np.sqrt(2)*v))
print(f"   Bendixson violations: {viol_b};  final-bound violations: {viol_f}")
print(f"   max lam_max/(sqrt2 v_FS) over random samples: {worst_ratio:.10f}")

print("\nSTEP 4.  SHARPNESS: resonant pure squeezer, plus spectator modes")
for N in range(1, 6):
    J = Jm(N)
    G = np.zeros((2*N, 2*N))
    G[0, 0] = 1.0; G[1, 1] = -1.0          # one resonant squeezer, rest exactly zero
    M = J @ G
    lam = np.max(np.real(np.linalg.eigvals(M)))
    v = np.linalg.norm(M + M.T)/4
    print(f"   N={N}:  lam_max={lam:.10f}  v_FS={v:.10f}  ratio={lam/(np.sqrt(2)*v):.12f}")

print("\n   squeezer + a PASSIVE part on the same mode (detuning): ratio must drop below 1")
J = Jm(1)
for d in [0.0, 0.3, 0.6, 0.9, 0.99]:
    G = np.diag([d + 1.0, d - 1.0]); M = J @ G
    lam = np.max(np.real(np.linalg.eigvals(M)))
    v = np.linalg.norm(M + M.T)/4
    print(f"     delta={d:4.2f}: lam={lam:.6f}  v_FS={v:.6f}  lam/(sqrt2 v)={lam/(np.sqrt(2)*v):.8f}"
          f"   sqrt(1-d^2)={np.sqrt(max(1-d*d,0)):.8f}")

print("\nSTEP 5.  passive additions: M_p = J G_p with [J,G_p]=0 is purely antisymmetric")
worst_p = 0.0
for N in [1, 2, 3, 4]:
    J = Jm(N)
    for _ in range(500):
        B = rng.normal(size=(2*N, 2*N)); X = (B + B.T)/2
        Gp = (X + J.T @ X @ J)/2                 # project onto [J,Gp]=0
        assert np.max(np.abs(J@Gp - Gp@J)) < 1e-12
        Mp = J @ Gp
        worst_p = max(worst_p, np.max(np.abs(Mp + Mp.T)))
print(f"   max |M_p + M_p^T| : {worst_p:.3e}   (zero => contributes nothing to v_FS)")
