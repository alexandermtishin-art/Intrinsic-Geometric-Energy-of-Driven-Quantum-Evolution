"""Chirped mode: squeezing rate against the frozen-flow exponent (Sec. S4).

Reproduces Table S2 of the Supplemental Material and the symplectic
normal-form check quoted in the same section.

Effective generator in the instantaneous-mode frame, in the quadratures (x, p):

    M = [[ b,  Omega],
         [-Omega, -b]],     b = kappa_s = eta*Omega/2,

with instantaneous eigenvalues +-lambda_loc, lambda_loc^2 = b^2 - Omega^2.
"""

import numpy as np

J = np.array([[0.0, 1.0], [-1.0, 0.0]])


def rates(eta, Omega=1.0):
    """Squeezing rate and frozen-flow exponent, in units of Omega."""
    kappa_s = eta * Omega / 2.0
    lam2 = kappa_s**2 - Omega**2
    lam = np.sqrt(lam2) if lam2 > 0 else np.nan
    return kappa_s, lam


def flow(eta, Omega=1.0):
    b = eta * Omega / 2.0
    return np.array([[b, Omega], [-Omega, -b]])


if __name__ == "__main__":
    print("TABLE S2.  Squeezing rate against the instantaneous frozen-flow exponent")
    print("  (no real lambda_loc below eta = 2; last column is the overestimate")
    print("   relative to lambda_loc)")
    print(f"  {'eta':>10}{'kappa_s/Om':>12}{'lam_loc/Om':>12}"
          f"{'ratio':>10}{'overestimate':>14}")
    for eta in [2.5, np.sqrt(8), 3.0, 4.0, 10.0]:
        ks, lam = rates(eta)
        label = "sqrt8 = 2.828" if abs(eta - np.sqrt(8)) < 1e-12 else f"{eta:.1f}"
        print(f"  {label:>10}{ks:12.3f}{lam:12.3f}{ks/lam:10.3f}"
              f"{100*(ks-lam)/lam:13.1f} %")

    print("\n  At eta = sqrt8 the squeezing rate exceeds lambda_loc by sqrt2:")
    ks, lam = rates(np.sqrt(8))
    print(f"    relative to lambda_loc : {100*(ks-lam)/lam:.1f} %")
    print(f"    relative to kappa_s    : {100*(ks-lam)/ks:.1f} %")

    print("\nSymplectic normal form of the frozen flow above threshold.")
    print("  The flow is conjugate, by a real symplectic V (V^T J V = J), to")
    print("  lambda_loc * diag(1, -1).")
    print(f"  {'eta':>6}{'lam_loc/Om':>12}{'|V^T J V - J|':>16}"
          f"{'|V^-1 M V - D|':>17}")
    for eta in [2.5, 4.0, 10.0]:
        M = flow(eta)
        _, lam = rates(eta)
        w, V = np.linalg.eig(M)
        order = np.argsort(-w.real)          # +lambda first
        w, V = w[order].real, V[:, order].real
        # normalise so that V^T J V = J
        s = V.T @ J @ V
        V = V / np.sqrt(abs(s[0, 1]))
        err_symp = np.max(np.abs(V.T @ J @ V - J))
        D = np.diag([lam, -lam])
        err_diag = np.max(np.abs(np.linalg.inv(V) @ M @ V - D))
        print(f"  {eta:6.1f}{lam:12.4f}{err_symp:16.2e}{err_diag:17.2e}")
    print("\n  The frozen effective generator above threshold is canonically a")
    print("  dilatation, but of rate lambda_loc and not of rate kappa_s.")
