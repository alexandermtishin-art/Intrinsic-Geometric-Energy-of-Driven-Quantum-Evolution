"""Panels of Fig. 1: the reciprocal families and the trajectories they generate.

(a) Family A: eps and delta co-varied so that lambda = lam0 is fixed while the
    geometric rate grows.
(b) Family B: eps fixed, so the geometric speed is constant while lambda falls
    to zero at threshold.
(c) Mean occupation along Family A: common exponential rate, different
    photon-production amplitudes.
(d) Mean occupation along Family B: common short-time behaviour, fanning slopes.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.size": 8, "axes.linewidth": 0.8, "font.family": "serif",
    "mathtext.fontset": "dejavuserif",
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.top": True, "ytick.right": True,
})


def occupation(delta, eps, t):
    """<n(t)> = (eps^2 / lambda^2) sinh^2(lambda t) from the bare-mode vacuum."""
    lam = np.sqrt(eps**2 - delta**2)
    return (eps**2 / lam**2) * np.sinh(lam * t)**2


fig, ax = plt.subplots(2, 2, figsize=(7.0, 4.2))

# ---- (a) Family A: fixed instability -------------------------------------
d = np.linspace(0, 5.2, 500)
ax[0, 0].plot(d, np.sqrt(1 + d**2), "-", lw=1.6,
              label=r"$\sqrt{2}\,v_{\rm FS}/\lambda_0$")
ax[0, 0].plot(d, np.ones_like(d), "--", lw=1.6, label=r"$\lambda/\lambda_0$")
ax[0, 0].set_xlabel(r"$\delta/\lambda_0$")
ax[0, 0].set_ylabel("normalized rate")
ax[0, 0].set_title("(a) Fixed instability", loc="left", fontweight="bold")
ax[0, 0].set_xlim(0, 5.2)
ax[0, 0].legend(frameon=False, loc="upper left")

# ---- (b) Family B: fixed geometric speed ---------------------------------
r = np.linspace(0, 1, 500)
ax[0, 1].plot(r, np.ones_like(r), "-", lw=1.6,
              label=r"$\sqrt{2}\,v_{\rm FS}/\varepsilon$")
ax[0, 1].plot(r, np.sqrt(np.clip(1 - r**2, 0, None)), "--", lw=1.6,
              label=r"$\lambda/\varepsilon$")
ax[0, 1].set_xlabel(r"$\delta/\varepsilon$")
ax[0, 1].set_ylabel("normalized rate")
ax[0, 1].set_title("(b) Fixed geometric speed", loc="left", fontweight="bold")
ax[0, 1].set_xlim(0, 1)
ax[0, 1].set_ylim(0, 1.25)
ax[0, 1].legend(frameon=False, loc="lower left")

# ---- (c) Family A trajectories -------------------------------------------
t = np.linspace(0.04, 2.0, 500)
for dl in [0.0, 1.0, 2.0, 3.0]:
    lam0 = 1.0
    delta = dl * lam0
    eps = np.sqrt(lam0**2 + delta**2)
    ax[1, 0].semilogy(t, occupation(delta, eps, t), lw=1.6,
                      label=rf"$\delta/\lambda_0={dl:.0f}$")
ax[1, 0].set_xlabel(r"$\lambda_0 t$")
ax[1, 0].set_ylabel(r"$\langle n(t)\rangle$")
ax[1, 0].set_title("(c) Family A trajectories", loc="left", fontweight="bold")
ax[1, 0].legend(frameon=False, ncol=2, fontsize=7, loc="lower right")

# ---- (d) Family B trajectories -------------------------------------------
t = np.linspace(0.04, 3.0, 500)
for de in [0.0, 0.5, 0.9, 0.99]:
    eps = 1.0
    ax[1, 1].semilogy(t, occupation(de * eps, eps, t), lw=1.6,
                      label=rf"$\delta/\varepsilon={de:g}$")
ax[1, 1].set_xlabel(r"$\varepsilon t$")
ax[1, 1].set_ylabel(r"$\langle n(t)\rangle$")
ax[1, 1].set_title("(d) Family B trajectories", loc="left", fontweight="bold")
ax[1, 1].legend(frameon=False, ncol=2, fontsize=7, loc="upper left")

for a in ax.ravel():
    a.tick_params(length=3)
    a.grid(alpha=0.15, lw=0.5)

fig.tight_layout()
fig.savefig("fig1_prl.png", dpi=300)
print("wrote fig1_prl.png")
