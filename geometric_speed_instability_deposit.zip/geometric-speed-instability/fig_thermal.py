import numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size":10,"axes.linewidth":0.8,"font.family":"serif",
    "mathtext.fontset":"dejavuserif","xtick.direction":"in","ytick.direction":"in",
    "xtick.top":True,"ytick.right":True})
n = np.linspace(0, 3, 600)
W = 1 + 2*n + 2*n**2
v  = np.sqrt(1 - 1/(2*W))          # hbar v / (hbar kappa_s)
dH = np.sqrt(W/2)                  # Delta H / (hbar kappa_s)
fig, ax = plt.subplots(figsize=(5.0, 3.6))
ax.plot(n, v,  "-",  lw=1.8, label=r"$v/\kappa_s=\sqrt{1-1/2W}$")
ax.plot(n, dH, "--", lw=1.8, label=r"$\Delta\hat{H}/\hbar\kappa_s=\sqrt{W/2}$")
ax.axhline(1, ls=":", lw=0.8, color="0.4")
ax.axhline(1/np.sqrt(2), ls=":", lw=0.8, color="0.4")
ax.plot([0],[1/np.sqrt(2)], "o", ms=6, color="C0")
ax.annotate(r"$\bar n=0$", (0.04, 0.60), fontsize=9)
ax.annotate(r"$1$", (2.86, 1.05), fontsize=9)
ax.annotate(r"$1/\sqrt{2}$", (2.66, 0.60), fontsize=9)
ax.set_xlabel(r"mean occupation $\bar n$")
ax.set_ylabel(r"rate, in units of $\kappa_s$")
ax.set_xlim(0, 3); ax.set_ylim(0, 4); ax.tick_params(length=3)
ax.legend(frameon=False, loc="upper left")
fig.tight_layout(); fig.savefig("fig_thermal.png", dpi=300); print("regenerated")
