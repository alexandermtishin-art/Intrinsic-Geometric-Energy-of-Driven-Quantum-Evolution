"""Reciprocal families of a detuned parametric amplifier.

Reproduces Tables 1 and 2 of the manuscript: along Family A the instability
exponent is held fixed while the short-time fidelity decay varies by two orders
of magnitude; along Family B the short-time decay is fixed while the occupation
reached at a fixed elapsed time varies by four orders of magnitude.

Closed-system evolution from the bare-mode vacuum under
    H = delta (x^2 + p^2)/2 + (eps/2)(x^2 - p^2).
"""

import numpy as np
from scipy.linalg import expm

J = np.array([[0.0, 1.0], [-1.0, 0.0]])
SIG_VAC = 0.5 * np.eye(2)


def flow(delta, eps):
    """Generator G and flow matrix M = JG."""
    G = np.diag([delta + eps, delta - eps])
    return G, J @ G


def v_fs(delta, eps):
    """Fubini-Study speed at the bare-mode vacuum, v = ||M + M^T||_F / 4."""
    _, M = flow(delta, eps)
    return np.linalg.norm(M + M.T) / 4.0


def lam(delta, eps):
    """Instability exponent of the closed flow."""
    return np.sqrt(max(eps**2 - delta**2, 0.0))


def covariance(delta, eps, t):
    _, M = flow(delta, eps)
    S = expm(M * t)
    return S @ SIG_VAC @ S.T


def occupation(delta, eps, t):
    """Mean photon number from the bare-mode vacuum."""
    return 0.5 * np.trace(covariance(delta, eps, t)) - 0.5


def fidelity(delta, eps, t):
    """Overlap with the initial state; for pure Gaussian states with
    Sigma_vac = I/2 this is F = 1 / sqrt(det(Sigma(t) + Sigma_vac))."""
    return 1.0 / np.sqrt(np.linalg.det(covariance(delta, eps, t) + SIG_VAC))


def growth_rate(delta, eps, t1=8.0, t2=10.0):
    return np.log(occupation(delta, eps, t2) / occupation(delta, eps, t1)) / (t2 - t1)


if __name__ == "__main__":
    T_SHORT = 0.02

    print("Closed-form occupation:  <n(t)> = 2 (v_FS / lambda)^2 sinh^2(lambda t)")
    worst = 0.0
    for d, e, t in [(0, 1, 1), (2, np.sqrt(5), 1), (0.9, 1, 1),
                    (5, np.sqrt(26), 3), (0.99, 1, 8), (0, 1, 6)]:
        num = occupation(d, e, t)
        closed = 2 * (v_fs(d, e) / lam(d, e))**2 * np.sinh(lam(d, e) * t)**2
        worst = max(worst, abs(num - closed) / num)
        print(f"  delta={d:5.2f} eps={e:6.3f} t={t:4.1f}"
              f"   numeric={num:.6e}  closed={closed:.6e}")
    print(f"  max relative deviation: {worst:.2e}")

    print("\nTABLE 1.  Family A: eps^2 - delta^2 = lam0^2 = 1, exponent fixed")
    print(f"  {'d/lam0':>7}{'sqrt2 v/lam0':>14}{'1-F':>13}{'dln<n>/dt':>12}")
    for dl in [0, 2, 5, 10]:
        lam0 = 1.0
        d = dl * lam0
        e = np.sqrt(lam0**2 + d**2)
        print(f"  {dl:7.0f}{np.sqrt(2)*v_fs(d, e)/lam0:14.3f}"
              f"{1 - fidelity(d, e, T_SHORT):13.3e}{growth_rate(d, e):12.6f}")

    print("\nTABLE 2.  Family B: eps = 1 fixed, geometric speed fixed")
    print(f"  {'d/eps':>7}{'lam/eps':>10}{'1-F':>13}{'<n> at t=8':>14}")
    for de in [0.0, 0.5, 0.9, 0.99]:
        e = 1.0
        d = de * e
        print(f"  {de:7.2f}{lam(d, e)/e:10.3f}"
              f"{1 - fidelity(d, e, T_SHORT):13.3e}{occupation(d, e, 8.0):14.3e}")

    print("\nQuadrature structure across Family A at lam0 t = 0.8 "
          "(distinct trajectories at identical exponent)")
    print(f"  {'d/lam0':>7}{'<n>':>10}{'Var_max/Var_min':>18}{'squeeze axis':>15}")
    for dl in [0.0, 1.0, 2.0, 3.0]:
        lam0 = 1.0
        d = dl * lam0
        e = np.sqrt(lam0**2 + d**2)
        Sig = covariance(d, e, 0.8)
        w, V = np.linalg.eigh(Sig)
        angle = np.degrees(np.arctan2(V[1, -1], V[0, -1]))
        print(f"  {dl:7.1f}{0.5*np.trace(Sig)-0.5:10.4f}"
              f"{w[-1]/w[0]:18.1f}{angle:14.1f} deg")

    print("\nElliptic sector (eps < delta): stable flow with nonvanishing speed")
    d, e = 3.0, 1.0
    print(f"  delta={d}, eps={e}:  lambda = 0,  v_FS = {v_fs(d, e):.6f}")
    print("  This case requires no theorem and is excluded from both families,")
    print("  which lie entirely inside the hyperbolic sector.")
