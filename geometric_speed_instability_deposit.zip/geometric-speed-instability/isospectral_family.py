"""
Corollary 1: generator-state pairs with identical flow spectra can have
parametrically different v_FS, so no finite upper bound on the geometric speed
can be a function of the flow spectrum alone.

Two independent demonstrations, corresponding to the two panels of Fig. S1.

(a) An explicit one-parameter family at N = 2.  The generator is replaced by
    G -> V(r)^T G V(r) along a family of symplectic squeezes of the reference
    quadratures, while the bare-vacuum covariance is held at Sigma = I/2.  The
    flow matrices M = JG are then related by similarity, M -> V^-1 M V, so the
    spectrum is invariant by construction while v_FS = ||M + M^T||_F / 4 is not.

(b) Random sampling, which does not use the construction at all: among two-mode
    generators whose geometric speed agrees to within 2 percent, the largest
    exponent still spans a wide range.

Base generator: mode 1 is the resonant pure squeezer of Eq. (4) at delta = 0,
which saturates Theorem 2; mode 2 is a detuned amplifier of the same family.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SEED = 20260818
R_MAX = 1.4
N_SAMPLES = 6000
BAND = 0.02

rng = np.random.default_rng(SEED)


def Jm(N):
    J = np.zeros((2 * N, 2 * N))
    for k in range(N):
        J[2 * k, 2 * k + 1] = 1.0
        J[2 * k + 1, 2 * k] = -1.0
    return J


J = Jm(2)
vfs = lambda G: np.linalg.norm(J @ G + (J @ G).T) / 4
lam = lambda G: float(np.max(np.real(np.linalg.eigvals(J @ G))))


def amp(eps, delta):
    """G block of Eq. (4): diag(delta+eps, delta-eps)."""
    return np.diag([delta + eps, delta - eps])


# --- base generator ---------------------------------------------------------
EPS1, DEL1 = 1.0, 0.0     # resonant pure squeezer: saturates Theorem 2
EPS2, DEL2 = 0.8, 0.6     # detuned amplifier, below the ceiling
G0 = np.zeros((4, 4))
G0[:2, :2] = amp(EPS1, DEL1)
G0[2:, 2:] = amp(EPS2, DEL2)


def V(r):
    """Symplectic squeeze of the reference quadratures, both modes."""
    return np.diag([np.exp(r), np.exp(-r), np.exp(r), np.exp(-r)])


lam0, v0 = lam(G0), vfs(G0)
print("BASE GENERATOR  G0 = diag(%.1f, %.1f, %.1f, %.1f)" % tuple(np.diag(G0)))
print("   lam_max = %.6f     v_FS = %.6f     sqrt2 v_FS = %.6f" % (lam0, v0, np.sqrt(2) * v0))
print()
print("(a) EXPLICIT ISOSPECTRAL FAMILY, r in [0, %.1f]" % R_MAX)
print("      r      v_FS      v_FS/v_FS(0)    lam_max     |lam_max - lam_max(0)|")

rs = np.linspace(0.0, R_MAX, 200)
vv, ll = [], []
for r in rs:
    Gr = V(r).T @ G0 @ V(r)
    vv.append(vfs(Gr))
    ll.append(lam(Gr))
vv, ll = np.array(vv), np.array(ll)
drift = float(np.max(np.abs(ll - lam0)))
for r in np.linspace(0.0, R_MAX, 8):
    Gr = V(r).T @ G0 @ V(r)
    print("   %5.3f   %8.5f   %10.4f    %9.6f   %.3e"
          % (r, vfs(Gr), vfs(Gr) / v0, lam(Gr), abs(lam(Gr) - lam0)))
print()
print("    spectrum invariant to        : %.1e" % drift)
print("    v_FS spread over the range   : factor %.4g" % (vv[-1] / vv[0]))
print()
print("    unbounded within the quadratic model (same spectrum at every row):")
print("        r      v_FS/v_FS(0)    |lam_max - lam_max(0)|")
for r in [2.0, 4.0, 6.0, 8.0]:
    Gr = V(r).T @ G0 @ V(r)
    print("     %5.2f   %13.4g    %.1e" % (r, vfs(Gr) / v0, abs(lam(Gr) - lam0)))

# --- (b) random corroboration ----------------------------------------------
vs = np.empty(N_SAMPLES)
ls = np.empty(N_SAMPLES)
for i in range(N_SAMPLES):
    A = rng.normal(size=(4, 4))
    G = A + A.T
    vs[i] = vfs(G)
    ls[i] = lam(G)
scale = np.median(vs)
vs, ls = vs / scale, ls / scale

band = np.abs(vs - 1.0) <= BAND
sel = ls[band]
ceiling = np.sqrt(2)                      # sqrt2 * v_FS at v_FS = 1
frac = sel.max() / ceiling
p5, p95 = np.percentile(sel, [5, 95])
print()
print("(b) RANDOM TWO-MODE GENERATORS (seed %d)" % SEED)
print("    samples                                   : %d" % N_SAMPLES)
print("    within %.0f%% of the median speed          : %d" % (100 * BAND, int(band.sum())))
print("    lam_max range in that band                : %.3e .. %.4f" % (sel.min(), sel.max()))
print("    samples with lam_max below 1e-12          : %d  (elliptic, stable at numerical precision)"
      % int(np.sum(sel < 1e-12)))
print("    ceiling sqrt2 v_FS at v_FS = 1            : %.4f" % ceiling)
print("    largest exponent reached, as a fraction   : %.3f of the ceiling" % frac)
print("    5th-95th percentile of lam_max in band    : %.4f .. %.4f  (ratio %.1f)" % (p5, p95, p95 / p5))
print("    bound lam_max <= sqrt2 v_FS violated      : %d times" % int(np.sum(ls > np.sqrt(2) * vs + 1e-12)))
print()
print("    The band statistic is quoted as coverage, not as a max/min ratio:")
print("    min/max over a finite sample is set by the single smallest draw and")
print("    is not a stable number. At fixed geometric speed the exponent covers")
print("    essentially the whole interval allowed by Theorem 2, from zero to the")
print("    ceiling, which is the content of Corollary 1.")

# --- figure -----------------------------------------------------------------
fig, ax = plt.subplots(1, 2, figsize=(12.0, 4.875), dpi=240)
ax[0].plot(rs, vv, "-", lw=2.2, color="#1f77b4", label=r"$v_{\rm FS}$ (reference-dependent)")
ax[0].plot(rs, ll, "--", lw=2.2, color="#d95f02", label=r"$\lambda_{\max}$ (symplectic invariant)")
ax[0].set_xlabel("squeeze parameter $r$ of the reference quadratures")
ax[0].set_ylabel("rate")
ax[0].set_title("(a) fixed flow, symplectic change of reference", loc="left")
ax[0].legend(frameon=False)
ax[0].set_xlim(0, R_MAX)

ax[1].plot(vs, ls, ".", ms=2.0, color="#7fb3d5", alpha=0.75)
xl = np.linspace(0, vs.max() * 1.02, 10)
ax[1].plot(xl, np.sqrt(2) * xl, "-", lw=1.4, color="0.25",
           label=r"Theorem 2: $\lambda_{\max}=\sqrt{2}\,v_{\rm FS}$")
ax[1].vlines(1.0, sel.min(), sel.max(), color="#e8820c", lw=4.0)
ax[1].annotate("numerical zero to %.2f of the ceiling" % frac, xy=(1.0, 0.5 * (sel.min() + sel.max())),
               xytext=(0.30, 0.82 * ls.max()),
               arrowprops=dict(arrowstyle="->", color="0.25"))
ax[1].set_xlabel(r"$v_{\rm FS}$")
ax[1].set_ylabel(r"$\lambda_{\max}$")
ax[1].set_title("(b) random generators, corroboration", loc="left")
ax[1].legend(frameon=False, loc="upper left")
ax[1].set_xlim(0, None)
ax[1].set_ylim(0, None)
fig.tight_layout()
fig.savefig("fig_isospectral.png")
print("\nwrote fig_isospectral.png")
