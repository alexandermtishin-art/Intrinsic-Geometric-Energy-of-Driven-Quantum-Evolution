# Identifying the instability threshold of a lossy parametric amplifier from two short-time return traces

Computational materials for the JOSA B manuscript by Alexander M. Tishin. The v25 directory retains the filenames of the reference calculations.

## Reproduce the calculations

Extract the archive. From its root, use Python 3.11 or later. The pinned
environment below was tested with Python 3.12.

```sh
python -m pip install -r requirements.txt
python reproduce.py --output-dir reproduced
```

The runner executes all 14 scripts and writes separate logs for the baseline and
v25 calculations. The shipped `results/` directory records the reference run.
All numbers and plots are model outputs.

| Manuscript item | Script | Reference output |
| --- | --- | --- |
| Fig. 1 | `v25/reciprocal_families.py` | `results/v25/reciprocal_families.png` and vector PDF |
| Fig. 2 and Eqs. (11)–(13) | `v25/gaussian_reference_cap.py` | Figure, vector PDF and verification log |
| Fig. 3 and Eqs. (14)–(20) | `v25/two_fidelity_threshold.py` | Figure, vector PDF and log with 120 inversions and the finite-window benchmark |
| Appendix A and Table II | `v25/appendix_a_v25.py` | `results/v25/appendix_a_table_ii.csv` and verification log |
| Baseline and Supplement S1–S6 | `legacy/` | Original scripts, reference output and supporting plots |

The v25 Table II script uses affine covariance propagation and solves the
crossings continuously. The last row uses the exact dissipative threshold
and yields 131.3 ns at 100 photons. The legacy open-window script uses a
rounded detuning and discrete output times.

## Provenance

The `legacy/` tree comes from `geometric_speed_instability_deposit.zip`
at commit `d6d59e49ff0136b11028401d402cfe7bf558a51a` as recorded in the original code deposit. Its original license is retained
as `legacy/LICENSE`. MAIN and the text of the Supplemental Material are
distributed separately.

The v31 presentation of Fig. 2 distinguishes the finite squeezing budgets by line pattern and marker shape. The numerical calculation uses the same inputs as the reference run.

## Phase cycle and shot-budget comparison in v34

Run `python v34/phase_cycled_threshold_v33.py` and `python v34/return_fisher_v34.py` from the archive root. Logs in `results/v34/` document Sections S9 and S10 of Supplement 1. The existing Appendix A check is now discussed in Section S11 and Table S5.

## Phase-sensitive diffusion in v35

Run `python v35/anisotropic_threshold_v35.py` from the archive root to verify Eq. (21) and the two-input counterexample in Supplement 1, Section S9.1. The existing Fisher calculation is for phase-insensitive diffusion.
