"""Check threshold recovery from phase-cycled returns with anisotropic diffusion."""
import numpy as np
from numpy.linalg import inv,det
from scipy.linalg import expm
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "v34"))
import phase_cycled_threshold_v33 as pc
rng=np.random.default_rng(3519)
def rot(a):
    return np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
def gmat(eps,delta,k,D):
    g=pc.drift(eps,delta,k,0.)
    g[:4,4]=D.ravel()
    return g
def estimate(cfs,r):
    l,b=cfs
    lm,bm=l[1:].mean(),b[1:].mean()
    s2=np.sinh(2*r)**2
    d=(lm-l[0])/(2*(np.cosh(2*r)-1))
    k=2*d-l[0]
    eiso=b[0]+k*l[0]+k*k/4-d*d
    qiso=(bm-b[0]+k*(lm-l[0]))/s2-eiso/2
    miso=eiso-qiso-k*k/4
    spread=((l[1:]-lm)**2).mean()
    aniso=spread/(2*s2)
    return miso,miso+1.5*aniso,k,d,aniso
mx=0
signs=[0,0]
for i in range(2000):
    eps,delta=rng.uniform(0,1.6),rng.uniform(-1.6,1.6)
    k=rng.uniform(.02,1.3)
    noise=k/2+rng.uniform(0,0.9)
    h=rng.uniform(0,1.0)
    ra=rot(rng.uniform(0,np.pi))
    D=ra @ np.diag(noise*np.exp([-h,h])) @ ra.T
    theta=rng.uniform(0,np.pi)
    r=rng.uniform(.15,1.1)
    cov=pc.covariances(r,theta+np.arange(3)*np.pi/3)
    l,b=pc.exact_coefficients(cov,gmat(eps,delta,k,D))
    mi,m,ka,d,u=estimate((l,b),r)
    truth=eps**2-delta**2-k**2/4
    target=(np.trace(D)/2)**2-det(D)
    res=max(abs(mi-(truth-1.5*target)),abs(m-truth),abs(ka-k),abs(u-target),abs(d-np.trace(D)/2))
    mx=max(mx,res)
    signs[int(truth>0)]+=1
assert mx < 1e-10
print('Random cases by margin sign:', signs, 'maximum absolute error:', mx)
r=.45;k=.4;delta=1.
for D,e2 in [(np.diag([.5,.5]),1.02),(np.diag([.7,.3]),1.06)]:
    g=gmat(e2**.5,delta,k,D)
    pair=pc.covariances(r,[np.pi/4])
    v=pc.exact_coefficients(pair,g)
    if e2 == 1.02:
        baseline = v
    else:
        np.testing.assert_allclose(v, baseline, atol=1e-12, rtol=0)
    print('Two-input coefficients:', v, 'true margin:', e2-delta**2-k*k/4)
    print('cycled',estimate(pc.exact_coefficients(pc.covariances(r,np.arange(3)*np.pi/3+.21),g),r))
    for timewindow in [.1,.05,.025]:
        times=timewindow*np.arange(1,9)/8
        cov=pc.covariances(r,np.arange(3)*np.pi/3+.21)
        x=pc.starts(cov)
        v=np.array([det(cov+(expm(t*g)@x)[:4].T.reshape(-1,2,2)) for t in times])
        coeff=np.linalg.lstsq(times[:,None]**np.arange(1,4),v-1,rcond=None)[0]
        print('finite window',timewindow,estimate(coeff[:2],r)[:2])
