"""Local binomial Fisher bounds for the two return protocols (NumPy/SciPy)."""
import numpy as np
from scipy.linalg import expm_frechet


def generator(eps, delta, kappa, diffusion):
    drift = np.array([[-kappa/2, delta-eps], [-delta-eps, -kappa/2]])
    g = np.zeros((5, 5))
    g[:4, :4] = np.kron(np.eye(2), drift) + np.kron(drift, np.eye(2))
    g[:4, 4] = (diffusion*np.eye(2)).ravel()
    return g


def inputs(r, theta, cycle):
    angles = theta + (np.arange(3)*np.pi/3 if cycle else np.zeros(1))
    s = np.sinh(2*r)
    shape = np.array([[[np.cos(2*t),np.sin(2*t)],
                       [np.sin(2*t),-np.cos(2*t)]] for t in angles])
    grad = np.array([[[-np.sin(2*t),np.cos(2*t)],
                     [np.cos(2*t),np.sin(2*t)]] for t in angles])
    return (np.concatenate([np.eye(2)[None]/2,(np.cosh(2*r)*np.eye(2)-s*shape)/2]),
            np.concatenate([np.zeros((1,2,2)),-s*grad]))


def probability_data(params, r, theta, cycle, times):
    cov, angle_derivative = inputs(r, theta, cycle)
    init = np.vstack([cov.reshape(len(cov),4).T,np.ones(len(cov))])
    init_angle = np.vstack([angle_derivative.reshape(len(cov),4).T,np.zeros(len(cov))])
    g = generator(*params)
    directions = [generator(*x) for x in np.eye(4)]
    for time in times:
        e, first = expm_frechet(time*g,time*directions[0])
        derivatives = [first]+[expm_frechet(time*g,time*dx,compute_expm=False) for dx in directions[1:]]
        v = cov+(e@init)[:4].T.reshape(-1,2,2)
        prob = np.linalg.det(v)**(-.5)
        vinv = np.linalg.inv(v)
        dv = [(dx@init)[:4].T.reshape(-1,2,2) for dx in derivatives]
        if cycle:
            dv.append(angle_derivative+(e@init_angle)[:4].T.reshape(-1,2,2))
        grad = np.column_stack([-.5*prob*np.trace(vinv@x,axis1=1,axis2=2) for x in dv])
        yield prob,grad


def variance_constant(params, r, theta, cycle, tmax=.1):
    rows=[]
    for p, grad in probability_data(params,r,theta,cycle,np.arange(1,9)*tmax/8):
        rows.extend(grad/np.sqrt(p*(1-p))[:,None])
    rows=np.asarray(rows)/np.sqrt(len(rows))
    _,sing,vh=np.linalg.svd(rows,full_matrices=False)
    if sing[-1]<1e-12*sing[0]:
        raise ValueError('rank-deficient Fisher design')
    eps,delta,kappa,_=params
    target=np.array([2*eps,-2*delta,-kappa/2]+[0]*(1+int(cycle)))
    return np.sum((vh@target/sing)**2)


def main():
    phases=np.linspace(0,np.pi/3,31)
    # Independently check analytic probability gradients with central differences.
    p=np.array([1.,.955,.4,.3]);theta=.19
    prob,g=next(probability_data(p,.45,theta,True,[.1]))
    h=1e-5
    for i in range(5):
        q=np.r_[p,theta]
        u,v=q.copy(),q.copy()
        u[i]+=h;v[i]-=h
        pp=next(probability_data(u[:4],.45,u[4],True,[.1]))[0]
        pm=next(probability_data(v[:4],.45,v[4],True,[.1]))[0]
        assert np.allclose((pp-pm)/(2*h),g[:,i],atol=5e-10,rtol=1e-5)
    print('All five probability-gradient columns verified')
    for delta in (.955,.995):
        p=(1,delta,.4,.3)
        m=1-delta**2-.4**2/4
        print(f'detuning={delta:.3f}, margin={m:+.6f}')
        for tmax in (.10,.20,.40):
            for r in (.30,.45,.60,.80):
                a=variance_constant(p,r,np.pi/4,False,tmax)
                b=np.array([variance_constant(p,r,t,True,tmax) for t in phases])
                print(f'tmax={tmax:.2f}, r={r:.2f}: {a:.7g}, [{b.min():.7g},{b.max():.7g}]; '
                      f'3sigma design shots {9*a/m**2:.7g}, [{9*b.min()/m**2:.7g},{9*b.max()/m**2:.7g}]')


if __name__=='__main__':
    main()
