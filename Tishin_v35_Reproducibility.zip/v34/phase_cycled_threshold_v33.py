"""Verify phase-cycled threshold recovery. Requires numpy and scipy."""
import numpy as np
from scipy.linalg import expm


def covariances(r, angles):
    diagonal = np.diag(np.exp([-2*r, 2*r])) / 2
    out = [np.eye(2)/2]
    for angle in angles:
        c, s = np.cos(angle), np.sin(angle)
        rotation = np.array([[c, -s], [s, c]])
        out.append(rotation @ diagonal @ rotation.T)
    return np.array(out)


def drift(pump, detuning, damping, diffusion):
    a = np.array([[-damping/2, detuning-pump], [-detuning-pump, -damping/2]])
    g = np.zeros((5, 5))
    g[:4, :4] = np.kron(a, np.eye(2)) + np.kron(np.eye(2), a)
    g[:4, 4] = (diffusion*np.eye(2)).ravel()
    return g


def starts(cov):
    return np.vstack([cov.reshape(-1, 4).T, np.ones(len(cov))])


def exact_coefficients(cov, g):
    x = starts(cov)
    u = (g @ x)[:4].T.reshape(-1, 2, 2)
    z = (g @ g @ x)[:4].T.reshape(-1, 2, 2)
    w = np.linalg.inv(2*cov)
    return np.array([np.trace(w@u, axis1=1, axis2=2),
                     np.trace(w@z, axis1=1, axis2=2)/2 + np.linalg.det(w@u)])


def fitted_coefficients(cov, g, samples):
    times = np.arange(1, samples+1)*0.1/samples
    x = starts(cov)
    determinants = np.array([np.linalg.det(cov+(expm(t*g)@x)[:4].T.reshape(-1,2,2))
                             for t in times])
    return np.linalg.lstsq(times[:, None]**np.arange(1,4), determinants-1, rcond=None)[0][:2]


def reconstruct(coeff, r, cycled):
    l, b = coeff
    c,s = np.cosh(2*r),np.sinh(2*r)
    contrast = l[1:].mean()-l[0]
    d = contrast/(2*(c-1))
    k = 2*d-l[0]
    e2 = b[0]-3*k*k/4+2*k*d-d*d
    q2 = (b[1:].mean()-b[0]+k*contrast)/s**2
    if cycled:
        q2 -= e2/2
    return np.array([e2,q2,k,d])


def margin(params):
    e2,q2,k,_ = params
    return e2-q2-k*k/4


def main():
    rng = np.random.default_rng(33)
    worst = 0
    for _ in range(100):
        e,q,k,r = rng.uniform(.1,1.2,4)
        d = k/2+rng.uniform(0,1)
        angles = rng.uniform(0,np.pi)+np.arange(3)*np.pi/3
        estimates = reconstruct(exact_coefficients(covariances(r,angles),drift(e,q,k,d)),r,True)
        worst=max(worst,np.max(np.abs(estimates-[e*e,q*q,k,d])))
    print(f'100 exact cases; max parameter residual {worst:.6g}')
    assert worst<1e-10
    r,k,d=.45,.4,.3
    h=np.deg2rad(.1)
    grid=np.linspace(0,np.pi,181,endpoint=False)
    for q in (.955,.995):
        m=1-q*q-k*k/4
        g=drift(1,q,k,d)
        reference=margin(reconstruct(fitted_coefficients(covariances(r,[np.pi/4]),g,8),r,False))
        estimates=np.array([margin(reconstruct(fitted_coefficients(covariances(r,t+np.arange(3)*np.pi/3),g,4),r,True)) for t in grid])
        bound=(2+4*abs(q)/np.tanh(2*r))*h
        print(f'detuning {q:.3f}: true {m:+.8f}; calibrated fit {reference:+.8f}; '
              f'cycled fit range [{estimates.min():+.8f},{estimates.max():+.8f}]; '
              f'angle-error bound {bound:.8f}')
        assert np.all(np.sign(estimates)==np.sign(m))
        assert np.ptp(estimates)<1e-10
        for _ in range(181):
            axes = rng.uniform(0,np.pi)+np.arange(3)*np.pi/3
            offset = rng.uniform(-h,h,3)
            perturbed = reconstruct(exact_coefficients(covariances(r,axes+offset),g),r,True)
            assert abs(margin(perturbed)-m) <= bound + 1e-12
    print('362 relative-angle perturbations satisfy the analytical margin bound')


if __name__ == '__main__':
    main()
