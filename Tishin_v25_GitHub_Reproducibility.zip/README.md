# Fubini–Study Speed and Short-Time Identification of Bosonic Instability

Computational materials for manuscript v25 by A. M. Tishin.

## Reproduce the calculations

Extract the archive. From its root, use Python 3.11 or later. The pinned
environment below was tested with Python 3.12.

```sh
python -m pip install -r requirements.txt
python reproduce.py --output-dir reproduced
```

The runner executes all 14 scripts and writes separate logs for the baseline and
v25 calculations. The shipped `results/` directory records the reference run.
All numbers and plots are model outputs.

| Manuscript item | Script | Reference output |
| --- | --- | --- |
| Fig. 1 | `v25/reciprocal_families.py` | `results/v25/reciprocal_families.png` and vector PDF |
| Fig. 2 and Eqs. (11)–(13) | `v25/gaussian_reference_cap.py` | Figure, vector PDF and verification log |
| Fig. 3 and Eqs. (14)–(20) | `v25/two_fidelity_threshold.py` | Figure, vector PDF and log with 120 inversions and the finite-window benchmark |
| Appendix A and Table II | `v25/appendix_a_v25.py` | `results/v25/appendix_a_table_ii.csv` and verification log |
| Baseline and Supplement S1–S6 | `legacy/` | Original scripts, reference output and supporting plots |

The v25 Table II script uses affine covariance propagation and solves the
crossings continuously. The last row uses the exact dissipative threshold
and yields 131.3 ns at 100 photons. The legacy open-window script uses a
rounded detuning and discrete output times.

## Provenance

The `legacy/` tree comes from `geometric_speed_instability_deposit.zip`
at commit `d6d59e49ff0136b11028401d402cfe7bf558a51a` in the repository
identified in manuscript reference [29]. Its original license is retained
as `legacy/LICENSE`. MAIN and the text of the Supplemental Material are
distributed separately.
