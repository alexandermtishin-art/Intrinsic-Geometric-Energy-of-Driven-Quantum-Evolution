#!/usr/bin/env python3
"""Plot the autonomous one-mode amplifier families from the exact formulas."""

import argparse
from pathlib import Path

import matplotlib
import numpy as np

matplotlib.use("Agg")
from matplotlib import pyplot as plt


def plot(output_dir):
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "mathtext.fontset": "stix",
        "axes.labelsize": 10,
        "axes.titlesize": 10,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.8,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "legend.fontsize": 8,
        "pdf.fonttype": 42,
    })
    fig, ((a, b), (c, d)) = plt.subplots(2, 2, figsize=(7.25, 4.65))
    fig.subplots_adjust(left=0.115, right=0.975, bottom=0.115, top=0.94,
                        wspace=0.34, hspace=0.50)

    blue, vermilion, green, purple = "#0072B2", "#D55E00", "#00825C", "#87569A"
    fixed = np.linspace(0.0, 5.2, 300)
    a.plot(fixed, np.sqrt(1.0 + fixed**2), color=blue, linewidth=1.6,
           label=r"$\sqrt{2}\,v_{\mathrm{FS}}/\lambda_0$")
    a.plot(fixed, np.ones_like(fixed), color=vermilion, linewidth=1.6,
           linestyle="--", label=r"$\lambda/\lambda_0$")
    a.set(xlim=(0, 5.2), ylim=(0.73, 5.50), xticks=np.arange(6),
          xlabel=r"$\delta/\lambda_0$", ylabel="Normalized rate")
    a.legend(loc="upper left", frameon=False, handlelength=2.0)

    fixed = np.linspace(0.0, 1.0, 500)
    b.plot(fixed, np.ones_like(fixed), color=blue, linewidth=1.6,
           label=r"$\sqrt{2}\,v_{\mathrm{FS}}/\epsilon$")
    b.plot(fixed, np.sqrt(1.0 - fixed**2), color=vermilion, linewidth=1.6,
           linestyle="--", label=r"$\lambda/\epsilon$")
    b.set(xlim=(0, 1), ylim=(-0.035, 1.18), xlabel=r"$\delta/\epsilon$",
          ylabel="Normalized rate", yticks=[0, 0.25, 0.5, 0.75, 1])
    b.legend(loc="lower left", frameon=False, handlelength=2.0)

    colors = [blue, vermilion, green, purple]
    styles = ["-", "--", "-.", ":"]
    t_a = np.linspace(0.035, 2.05, 320)
    for detuning, color, style in zip([0, 1, 2, 3], colors, styles):
        population = (1.0 + detuning**2) * np.sinh(t_a)**2
        c.plot(t_a, population, color=color, linewidth=1.5, linestyle=style,
               label=fr"$\delta/\lambda_0={detuning}$")
    c.set(xlim=(0, 2.10), ylim=(0.001, 200), yscale="log",
          xticks=[0, 0.5, 1, 1.5, 2], xlabel=r"$\lambda_0 t$", ylabel=r"$\langle n(t)\rangle$")

    t_b = np.linspace(0.035, 3.05, 320)
    for detuning, color, style in zip([0, 0.5, 0.9, 0.99], colors, styles):
        rate = np.sqrt(1.0 - detuning**2)
        population = (np.sinh(rate * t_b) / rate)**2
        d.plot(t_b, population, color=color, linewidth=1.5, linestyle=style,
               label=fr"$\delta/\epsilon={detuning}$")
    d.set(xlim=(0, 3.10), ylim=(0.001, 200), yscale="log",
          xticks=[0, 0.5, 1, 1.5, 2, 2.5, 3], xlabel=r"$\epsilon t$", ylabel=r"$\langle n(t)\rangle$")

    for axis in (c, d):
        axis.legend(loc="lower right", ncol=2, columnspacing=0.9,
                    frameon=False, handlelength=1.85)
    for axis, title in zip((a, b, c, d), (
        "(a) Fixed instability",
        "(b) Fixed geometric speed",
        "(c) Family A trajectories",
        "(d) Family B trajectories",
    )):
        axis.set_title(title, loc="left", weight="semibold")
        axis.tick_params(length=3.0, width=0.75)
        axis.grid(axis="y", color="#E2E5E8", linewidth=0.55, zorder=0)

    output_dir.mkdir(parents=True, exist_ok=True)
    for extension in ["png", "pdf"]:
        fig.savefig(output_dir / f"reciprocal_families.{extension}", dpi=400,
                    facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    plot(parser.parse_args().output_dir)
