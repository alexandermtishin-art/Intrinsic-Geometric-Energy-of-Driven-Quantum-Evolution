#!/usr/bin/env python3
"""Check and plot the optimal one-mode Gaussian-reference speed.

Run: python gaussian_reference_cap.py [--output-dir DIR]
Requires NumPy, SciPy, and Matplotlib.
"""

import argparse
from pathlib import Path

import matplotlib
import numpy as np
from scipy.linalg import expm
from scipy.optimize import minimize

matplotlib.use("Agg")
from matplotlib import pyplot as plt


def speed_ratio(detuning, cap):
    """Return v_opt/v_vac at |delta/epsilon| and squeeze cap r_max."""
    x = np.asarray(detuning, dtype=float)
    if cap == 0:
        return np.ones_like(x)
    floor = np.sqrt(np.maximum(0.0, 1.0 - x**2))
    if np.isinf(cap):
        return floor
    lower = np.tanh(2.0 * cap)
    capped = (1.0 - x) * np.exp(2.0 * cap) / 2.0
    capped += (1.0 + x) * np.exp(-2.0 * cap) / 2.0
    return np.where(x <= lower, floor, np.maximum(0.0, capped))


def covariance_ratio_squared(delta, epsilon, squeeze, angle):
    """Use the Gaussian variance formula for H=(1/2) z^T G z."""
    c, s = np.cos(angle), np.sin(angle)
    rotation = np.array([[c, -s], [s, c]])
    covariance = 0.5 * rotation @ np.diag(np.exp([-2 * squeeze, 2 * squeeze])) @ rotation.T
    g = np.diag([delta + epsilon, delta - epsilon])
    j = np.array([[0.0, 1.0], [-1.0, 0.0]])
    gv, gj = g @ covariance, g @ j
    variance = 0.5 * np.trace(gv @ gv) + 0.125 * np.trace(gj @ gj)
    return 2.0 * variance / epsilon**2


def verify():
    """Cross-check the cap law by optimizing the raw covariance variance."""
    errors = []
    detunings = [0.0, 0.12, 0.4, 0.7, 0.9, 0.99, 1.0, 1.01, 1.1, 1.5, 2.3, 4.0]
    for cap in [0.0, 0.14, 0.25, 0.55, 1.0, 1.2]:
        samples = list(detunings)
        if cap:
            lower = np.tanh(2 * cap)
            samples += [lower, 1 / lower]
        for x in samples:
            for delta, epsilon in [(x, 1.0), (-x, 1.0), (x, -1.0)]:
                expected = speed_ratio(x, cap)**2
                if cap == 0:
                    observed = covariance_ratio_squared(delta, epsilon, 0, 0)
                else:
                    fits = [
                        minimize(
                            lambda u: covariance_ratio_squared(delta, epsilon, *u),
                            x0=[fraction * cap, angle],
                            bounds=[(0.0, cap), (0.0, np.pi / 2)],
                            method="L-BFGS-B",
                            options={"ftol": 1e-14, "gtol": 1e-10},
                        )
                        for fraction in [0.0, 0.5, 1.0]
                        for angle in [0.0, np.pi / 4, np.pi / 2]
                    ]
                    observed = min(fit.fun for fit in fits)
                errors.append(abs(observed - expected))
    max_error = max(errors)
    assert max_error < 3e-10, max_error
    print(f"{len(errors)} cases: maximum absolute error in squared speed ratio = {max_error:.3g}")

    fidelity_errors = []
    threshold_flow = np.array([[0.0, 0.0], [-2.0, 0.0]])
    for cap in [0.0, 0.25, 0.55, 1.0, 1.2]:
        initial = 0.5 * np.diag(np.exp([-2 * cap, 2 * cap]))
        for time in [0.01, 0.1, 0.5, 1.0, 3.0]:
            propagator = expm(time * threshold_flow)
            evolved = propagator @ initial @ propagator.T
            observed = 1.0 / np.sqrt(np.linalg.det(initial + evolved))
            expected = 1.0 / np.sqrt(1.0 + (time * np.exp(-2 * cap))**2)
            fidelity_errors.append(abs(observed - expected))
    fidelity_error = max(fidelity_errors)
    assert fidelity_error < 1e-12, fidelity_error
    print(f"{len(fidelity_errors)} threshold cases: maximum absolute fidelity error = {fidelity_error:.3g}")


def plot(output_dir):
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "mathtext.fontset": "stix",
        "axes.labelsize": 11,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.8,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "legend.fontsize": 9,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
    })
    colors = ["#0072B2", "#D55E00", "#00825C"]
    caps = [0.25, 0.55, 1.0]
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.25, 2.95), sharey=True)
    fig.subplots_adjust(left=0.10, right=0.98, bottom=0.20, top=0.79, wspace=0.17)

    detuning = np.sort(np.r_[np.linspace(0, 1.65, 800), 1])
    bare_line, = left.plot(detuning, speed_ratio(detuning, 0.0), color="#646A72",
                           linewidth=1.3, label=r"$R=0$")
    floor_line, = left.plot(detuning, speed_ratio(detuning, np.inf), color="#20242A",
                            linestyle="--", linewidth=1.4, label="No cap")
    left.axvline(1.0, color="#80868F", linewidth=0.9, linestyle=":", zorder=0)

    cap_lines = []
    for cap, color in zip(caps, colors):
        onset = np.tanh(2 * cap)
        end = min(1 / onset, detuning[-1])
        active = np.linspace(onset, end, 250)
        line, = left.plot(active, speed_ratio(active, cap), color=color,
                          linewidth=1.8, label=fr"$R={cap:.2f}$")
        cap_lines.append(line)
    left.set(xlim=(0, 1.65), ylim=(-0.038, 1.06),
             xlabel=r"Detuning $|\delta/\epsilon|$",
             ylabel=r"Optimal speed $v_{\mathrm{opt}}/v_{\mathrm{bare}}$",
             xticks=[0, 0.5, 1.0, 1.5], yticks=[0, 0.25, 0.5, 0.75, 1])

    occupation = np.linspace(0, 3.0, 650)
    threshold_ratio = 1.0 / (np.sqrt(occupation + 1) + np.sqrt(occupation))**2
    right.plot(occupation, threshold_ratio, color="#20242A", linewidth=1.6)
    for cap, color in zip(caps, colors):
        right.scatter(np.sinh(cap)**2, np.exp(-2 * cap), color=color, s=23,
                      edgecolor="white", linewidth=0.6, zorder=3)
    right.set(xlim=(0, 3.0), xticks=[0, 1, 2, 3],
              xlabel=r"Input photon-number cap $\bar n$")

    for ax, label in [(left, "(a)"), (right, "(b)")]:
        ax.text(0.0, 1.035, label, transform=ax.transAxes, va="bottom",
                fontweight="semibold")
        ax.tick_params(length=3.0, width=0.75)
    fig.legend(handles=[bare_line, *cap_lines, floor_line], loc="upper center",
               bbox_to_anchor=(0.54, 0.995), ncol=5, frameon=False,
               handlelength=2.0, columnspacing=1.55)

    output_dir.mkdir(parents=True, exist_ok=True)
    for extension in ["png", "pdf"]:
        fig.savefig(output_dir / f"gaussian_reference_cap.{extension}", dpi=400,
                    facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    verify()
    plot(args.output_dir)
