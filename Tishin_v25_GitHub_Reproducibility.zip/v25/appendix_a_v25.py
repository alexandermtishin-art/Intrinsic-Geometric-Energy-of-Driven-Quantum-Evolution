"""Reproduce Table II and the Appendix A growth windows using affine covariance."""
import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.linalg import expm
from scipy.optimize import brentq


def table():
    epsilon, kappa = 2 * np.pi * np.array([0.05, 0.02])  # angular rates per ns
    vacuum = (np.eye(2) / 2).ravel()
    initial = np.r_[vacuum, 1.0]
    threshold = np.sqrt(1 - (kappa / (2 * epsilon))**2)
    for x in [0, 0.5, 0.8, 0.9, 0.95, threshold]:
        delta = x * epsilon
        rate = 2 * np.sqrt(epsilon**2 - delta**2) - kappa
        drift = np.array([[-kappa / 2, delta - epsilon], [-delta - epsilon, -kappa / 2]])
        affine = np.zeros((5, 5))
        affine[:4, :4] = np.kron(np.eye(2), drift) + np.kron(drift, np.eye(2))
        affine[:4, 4] = kappa * vacuum

        def state(t):
            return expm(t * affine) @ initial

        def n(t):
            y = state(t)
            return (y[0] + y[3] - 1) / 2

        sat = brentq(lambda t: n(t) - 100, 0, 250)
        t5 = efolds = None
        if rate > 1e-12:
            def excess(t):
                y = state(t)
                derivative = affine @ y
                slope = (derivative[0] + derivative[3]) / (y[0] + y[3] - 1)
                return abs(slope - rate) / rate - 0.05

            t5 = brentq(excess, 0.01, 200)
            efolds = max(0, rate * (sat - t5))
        infidelity = 1 - np.linalg.det(
            state(0.5)[:4].reshape(2, 2) + vacuum.reshape(2, 2)
        )**(-0.5)
        yield [x, 1000 * delta / (2 * np.pi), 1000 * (rate + kappa) / (4 * np.pi),
               rate, n(20), sat, t5, efolds, infidelity]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = list(table())
    assert [round(row[5], 1) for row in rows] == [11.5, 13.0, 18.2, 25.3, 38.6, 131.3]
    assert [round(rows[i][6], 1) for i in [0, 2]] == [7.1, 13.7]
    assert [round(rows[i][7], 1) for i in [0, 2, 3, 4]] == [2.2, 1.1, 0.4, 0.0]
    with (args.output_dir / "appendix_a_table_ii.csv").open("w", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(["delta_over_epsilon", "detuning_MHz", "lambda_MHz",
                         "occupation_growth_rate_per_ns", "n_at_20_ns", "t_sat_ns",
                         "t_settle_5_percent_ns", "usable_e_folds", "infidelity_at_0p5_ns"])
        writer.writerows(rows)
    print("Table II and Appendix A growth windows verified")
