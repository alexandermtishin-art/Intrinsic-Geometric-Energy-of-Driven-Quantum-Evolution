#!/usr/bin/env python3
"""Verify the two-fidelity reconstruction and generate Fig. 3.

Run: python two_fidelity_threshold.py [--output-dir DIR]
Requires NumPy, SciPy, and Matplotlib.
"""

import argparse
from pathlib import Path

import matplotlib
import numpy as np
from scipy.linalg import expm

matplotlib.use("Agg")
from matplotlib import pyplot as plt


def input_covariances(squeeze):
    """Bare covariance and the covariance squeezed at pi/4."""
    rotation = np.array([[1.0, -1.0], [1.0, 1.0]]) / np.sqrt(2)
    squeezed = rotation @ np.diag(np.exp([-2 * squeeze, 2 * squeeze])) @ rotation.T
    return np.array([np.eye(2), squeezed]) / 2


def affine_generator(pump, detuning, damping, diffusion):
    """Propagate the four covariance entries and one constant coordinate."""
    drift = np.array([[-damping / 2, detuning - pump],
                      [-detuning - pump, -damping / 2]])
    affine = np.zeros((5, 5))
    affine[:4, :4] = np.kron(np.eye(2), drift) + np.kron(drift, np.eye(2))
    affine[:4, 4] = (diffusion * np.eye(2)).ravel()
    return affine


def initial_vectors(covariances):
    return np.vstack([covariances.reshape(2, 4).T, np.ones(2)])


def determinant_traces(times, covariances, generator):
    """Evaluate D_i=F_i^(-2) by the exact affine matrix exponential."""
    starts = initial_vectors(covariances)
    evolved = np.array([(expm(t * generator) @ starts)[:4].T.reshape(2, 2, 2)
                        for t in times])
    return np.linalg.det(covariances + evolved)


def determinant_coefficients(covariances, generator):
    """Expand det(2V + t V' + t² V''/2) by its entries."""
    starts = initial_vectors(covariances)
    first = (generator @ starts)[:4].T.reshape(2, 2, 2)
    second = (generator @ generator @ starts)[:4].T.reshape(2, 2, 2)
    adjugates = np.linalg.inv(covariances) * np.linalg.det(covariances)[:, None, None]
    linear = 2 * np.trace(adjugates @ first, axis1=1, axis2=2)
    quadratic = np.trace(adjugates @ second, axis1=1, axis2=2) + np.linalg.det(first)
    return np.array([linear, quadratic])


def reconstruct(coefficients, squeeze):
    """Return (pump², detuning², damping, diffusion) from both traces."""
    (l0, l45), (b0, b45) = coefficients
    cosh, sinh = np.cosh(2 * squeeze), np.sinh(2 * squeeze)
    contrast = l45 - l0
    diffusion = contrast / (2 * (cosh - 1))
    damping = 2 * diffusion - l0
    pump_squared = b0 - 3 * damping**2 / 4 + 2 * damping * diffusion - diffusion**2
    detuning_squared = (b45 - b0 + damping * contrast) / sinh**2
    return np.array([pump_squared, detuning_squared, damping, diffusion])


def margin_and_readout_bound(coefficients, squeeze, errors):
    """Bound the change of the finite-window margin under bounded input errors.

    The envelope measures deterministic sensitivity to errors in the supplied
    determinant traces. It excludes the finite-window Taylor bias.
    """
    (l0, l45), _ = coefficients
    pump_squared, detuning_squared, damping, diffusion = reconstruct(coefficients, squeeze)
    margin = pump_squared - detuning_squared - damping**2 / 4
    contrast = l45 - l0
    cosh_minus_one = np.cosh(2 * squeeze) - 1
    sinh_squared = np.sinh(2 * squeeze)**2

    err_l, err_b = errors
    err_contrast = 2 * err_l
    err_damping = err_contrast / cosh_minus_one + err_l
    err_damping_minus_diffusion = err_contrast / (2 * cosh_minus_one) + err_l
    # m = (1+1/S²)b0 - b45/S² - (damping-diffusion)² - damping*contrast/S².
    bound = (1 + 2 / sinh_squared) * err_b
    bound += ((2 * abs(damping - diffusion) + err_damping_minus_diffusion)
              * err_damping_minus_diffusion)
    bound += (abs(damping) * err_contrast + abs(contrast) * err_damping
              + err_damping * err_contrast) / sinh_squared
    return margin, bound


def verify():
    """Test exact initial-coefficient inversion across all three regimes."""
    rng = np.random.default_rng(6151)
    worst = 0.0
    for j in range(120):
        pump = rng.uniform(0.1, 2.0)
        damping = rng.uniform(0, 1.5 * pump)
        diffusion = damping * rng.uniform(0.5, 1.9)
        ratios = [0.3, np.sqrt(1 - (damping / (2 * pump))**2), 1.0, 1.3]
        detuning = (-1)**j * pump * ratios[j % 4]
        squeeze = rng.uniform(0.15, 1.1)
        generator = affine_generator(pump, detuning, damping, diffusion)
        coefficients = determinant_coefficients(input_covariances(squeeze), generator)
        expected = np.array([pump**2, detuning**2, damping, diffusion])
        worst = max(worst, np.max(np.abs(reconstruct(coefficients, squeeze) - expected)))
    assert worst < 1e-11, worst
    print(f"120 initial-coefficient checks: max absolute parameter error {worst:.3e}")


def benchmark(output_dir):
    squeeze, damping, thermal = 0.45, 0.4, 1.5
    pump, duration, readout_error = 1.0, 0.1, 1e-6
    diffusion = damping * thermal / 2
    threshold = np.sqrt(pump**2 - damping**2 / 4)
    covariances = input_covariances(squeeze)
    times = np.arange(1, 9) * duration / 8
    powers = np.arange(1, 4)
    fit = np.linalg.pinv((times[:, None] / duration)**powers) / duration**powers[:, None]
    errors = np.abs(fit[:2]).sum(axis=1) * readout_error

    def observations(detuning, t):
        generator = affine_generator(pump, detuning, damping, diffusion)
        return determinant_traces(t, covariances, generator)

    def margin_at(detuning):
        coefficients = fit[:2] @ (observations(detuning, times) - 1)
        return margin_and_readout_bound(coefficients, squeeze, errors)

    plot_times = np.linspace(0, duration, 160)
    detunings = np.linspace(0.945, 1.003, 200)
    exact = pump**2 - detunings**2 - damping**2 / 4
    fitted, bound = np.array([margin_at(x) for x in detunings]).T
    print(f"Max finite-window bias on the plotted grid: {np.max(np.abs(fitted - exact)):.6g}")
    print(f"Max readout sensitivity bound on the plotted grid: {np.max(bound):.6g}")
    cases = [0.955, threshold, 0.995]
    for x in cases:
        center, halfwidth = margin_at(x)
        print(f"detuning={x:.9f}, true m={pump**2-x*x-damping*damping/4:+.8f}, "
              f"fit m={center:+.8f}, readout envelope=[{center-halfwidth:+.8f},"
              f"{center+halfwidth:+.8f}]")

    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "mathtext.fontset": "stix",
        "axes.labelsize": 10.5,
        "axes.spines.right": False,
        "axes.spines.top": False,
        "axes.linewidth": 0.8,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "legend.fontsize": 8.2,
        "pdf.fonttype": 42,
    })
    blue, orange, green, dark = "#0072B2", "#D55E00", "#00825C", "#20242A"
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.25, 3.08))
    fig.subplots_adjust(left=0.09, right=0.98, bottom=0.18, top=0.88, wspace=0.39)

    contrast_slope = 2 * diffusion * (np.cosh(2 * squeeze) - 1)
    for x, color, style, label in zip(cases, [blue, dark, orange], ["-", ":", "--"], [
            r"$\delta/\epsilon=0.955$",
            "Dissipative boundary",
            r"$\delta/\epsilon=0.995$",
    ]):
        bare, squeezed = observations(x, plot_times).T
        contrast = squeezed - bare - contrast_slope * plot_times
        left.plot(plot_times, 1e3 * contrast, color=color, linestyle=style, linewidth=1.65,
                  label=label)
    left.set(xlim=(0, 0.1), ylim=(0, 9.6),
             xlabel=r"Dimensionless time $\epsilon t$",
             ylabel=r"$10^3[D_{45}-D_0-(\ell_{45}-\ell_0)t]$",
             xticks=[0, .025, .05, .075, .1])
    left.set_xticklabels(["0", "0.025", "0.050", "0.075", "0.100"])
    left.legend(loc="upper left", frameon=False, handlelength=2.3)

    right.axhline(0, color="#A9AFB5", linewidth=0.8, zorder=0)
    right.axvline(threshold, ymax=0.66, color="#949AA2", linestyle=":",
                  linewidth=0.85, zorder=1)
    right.fill_between(detunings, fitted - bound, fitted + bound, color="#AEDDCB",
                       alpha=0.65, linewidth=0, label="Readout-error envelope", zorder=1)
    right.plot(detunings, exact, color=dark, linestyle="--", linewidth=1.15,
               label="Exact margin", zorder=4)
    right.plot(detunings, fitted, color=green, linewidth=1.65,
               label="Finite-window fit", zorder=3)
    right.scatter([cases[0], cases[2]], [pump**2 - cases[0]**2 - damping**2 / 4,
                  pump**2 - cases[2]**2 - damping**2 / 4], s=21, c=[blue, orange],
                  linewidth=0.55, edgecolors="white", zorder=5)
    right.set(xlim=(detunings[0], detunings[-1]), ylim=(-0.062, 0.086),
              xlabel=r"Detuning $\delta/\epsilon$", ylabel=r"Growth margin $m/\epsilon^2$",
              xticks=[.95, .97, .99])
    handles, labels = right.get_legend_handles_labels()
    right.legend([handles[i] for i in (1, 2, 0)], [labels[i] for i in (1, 2, 0)],
                 loc="upper right", frameon=False, handlelength=2.1)

    for axis, title in ((left, "(a) Differential return signal"), (right, "(b) Growth margin")):
        axis.set_title(title, loc="left", weight="semibold", fontsize=10.4)
        axis.tick_params(length=3, width=0.75)
        axis.grid(axis="y", color="#E6E8EB", linewidth=0.55, zorder=0)

    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_dir / "two_fidelity_threshold.png", dpi=400, facecolor="white")
    fig.savefig(output_dir / "two_fidelity_threshold.pdf", facecolor="white",
                metadata={"CreationDate": None})
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    verify()
    benchmark(args.output_dir)
