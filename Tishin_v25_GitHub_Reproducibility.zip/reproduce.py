"""Run the archived baseline calculations and the v25 figures and checks."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LEGACY = [
    "theorem1_identity", "theorem2_sharp_bound", "isospectral_family",
    "reciprocal_families", "photon_number_and_open_window", "chirped_mode",
    "parametric_resonance", "mixed_state_thermal", "fig1_prl", "fig_thermal",
]
CURRENT = [
    "reciprocal_families", "gaussian_reference_cap", "two_fidelity_threshold",
    "appendix_a_v25",
]


def run(script, target, arguments):
    target.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, MPLBACKEND="Agg", OPENBLAS_NUM_THREADS="1")
    log = target / f"{script.stem}.log"
    with log.open("w", encoding="utf-8") as output:
        subprocess.run([sys.executable, str(script), *arguments], cwd=target,
                       env=environment, stdout=output, stderr=subprocess.STDOUT, check=True)
    print(f"OK {script.parent.name}/{script.name}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("reproduced"))
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    for name in LEGACY:
        run(ROOT / "legacy" / f"{name}.py", destination / "legacy", [])
    for name in CURRENT:
        target = destination / "v25"
        run(ROOT / "v25" / f"{name}.py", target, ["--output-dir", str(target)])
